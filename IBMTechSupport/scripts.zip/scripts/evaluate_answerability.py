"""Compatibility entry point; defaults to saved answerability evaluation."""
from evaluate.common import PROJECT_DIR, measure
from evaluate.evaluate_answerability import main
INPUT_PATH = PROJECT_DIR / "results" / "rag_val_clean_reranker_k5_predictions.jsonl"
OUTPUT_PATH = PROJECT_DIR / "results" / "answerability_evaluation.jsonl"

if __name__ == "__main__":
    main()
