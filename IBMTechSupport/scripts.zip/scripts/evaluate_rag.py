"""Compatibility entry point for the evaluation package."""
from evaluate.evaluate_rag import (BASE_METRICS_PATH, load_records, result_paths,
    retrieve_all, create_predictions, evaluate, compare, main)

if __name__ == "__main__":
    main()
