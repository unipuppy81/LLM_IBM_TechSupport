"""Compare saved Base, Hybrid RAG, and Reranker RAG metrics."""
import argparse
import json
from pathlib import Path
from .common import RESULT_DIR, check_output, load_jsonl, load_records, save_json, validate_prediction_rows


def compare(top_k=5, files=None, output=None):
    check_output(output)
    if not 1 <= top_k <= 50:
        raise ValueError("top_k must be 1..50")
    records = load_records()
    files = files or {
        "Base Model": RESULT_DIR / "base_val_clean_b4_metrics.json",
        "Hybrid RAG": RESULT_DIR / f"rag_val_clean_hybrid_k{top_k}_metrics.json",
        "Reranker RAG": RESULT_DIR / f"rag_val_clean_reranker_k{top_k}_metrics.json",
    }
    compared = {}
    print("Model                 EM%      F1%  Correct Abstain%  False Refusal%")
    for name, path in files.items():
        path = Path(path)
        if not path.is_file():
            print(f"{name}: not evaluated (missing {path.name})")
            continue
        
        metrics = json.loads(path.read_text(encoding="utf-8-sig"))
        if metrics.get("dataset") != "clean" or metrics.get("total") != len(records):
            print(f"{name}: excluded (different evaluation dataset)")
            continue

        prediction_path = path.with_name(path.name.replace("_metrics.json", "_predictions.jsonl"))

        if prediction_path != path and prediction_path.is_file():
            try:
                validate_prediction_rows(records, load_jsonl(prediction_path))
            except (KeyError, ValueError) as exc:
                print(f"{name}: excluded ({exc})")
                continue
            verification = "predictions"
        else:
            verification = "metadata_only"
            print(f"{name}: no predictions; only dataset/total metadata verified")

        compared[name] = {**metrics, "comparison_verification": verification}
        values = [metrics.get(k) for k in ("exact_match_percent", "token_f1_percent", "abstention_rate_percent", "false_refusal_rate_percent")]
        print(f"{name:<18}" + " ".join(f"{v:>12.2f}" if v is not None else f"{'N/A':>12}" for v in values))

    print("EM/F1: answerable questions; abstention: respective label subsets.")
    print("Base Batch=4 and RAG Batch=1 timings are not directly comparable.")
    if output:
        save_json(output, compared)
    return compared


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--top-k", type=int, default=5)
    p.add_argument("--base-metrics", type=Path)
    p.add_argument("--hybrid-metrics", type=Path)
    p.add_argument("--reranker-metrics", type=Path)
    p.add_argument("--output", type=Path)
    a = p.parse_args(argv)
    files = {name: path for name, path in (("Base Model", a.base_metrics), ("Hybrid RAG", a.hybrid_metrics), ("Reranker RAG", a.reranker_metrics)) if path}
    return compare(a.top_k, files or None, a.output)


if __name__ == "__main__":
    main()
