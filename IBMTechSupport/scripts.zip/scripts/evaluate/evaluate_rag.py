import argparse
import json
import time
from pathlib import Path

import torch
import yaml

from .common import load_model, score_predictions, save_jsonl, report

PROJECT_DIR = Path(__file__).resolve().parents[2]


# 1. YAML 설정 로드
def load_config(config_path):
    with open(config_path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


# 2. RAG 문서 검색
def retrieve_all(questions, method, top_k):
    from dense_search import load_retriever, chunk_filename
    from hybrid_search import load_bm25, search_all, BM25_INDEX_DIR
    from reranker_search import load_reranker, rerank_candidates, get_chunk_text

    if not (BM25_INDEX_DIR / "params.index.json").is_file():
        raise FileNotFoundError("Hybrid BM25 인덱스가 없습니다.")

    embedding_model, faiss_index, chunks = load_retriever()
    bm25_index = load_bm25(chunks)
    reranker = load_reranker() if method == "reranker" else None
    start = time.perf_counter()
    results = search_all(embedding_model, faiss_index, bm25_index, questions)

    hybrid_rankings = [result[2] for result in results]

    if reranker is None:
        selected = [
            [
                {
                    "row_id": row_id,
                    "score": result[3][row_id],
                }
                for row_id in result[2][:top_k]
            ]
            for result in results
        ]
    else:
        reranked = rerank_candidates(reranker, questions, hybrid_rankings, chunks)
        selected = [items[:top_k] for items in reranked]

    documents_by_question = []

    for items in selected:
        documents = []

        for item in items:
            chunk = chunks[item["row_id"]]
            documents.append({
                "chunk_id": chunk.get("chunk_id"),
                "filename": chunk_filename(chunk),
                "text": get_chunk_text(chunk),
                "score": float(item["score"]),
            })

        documents_by_question.append(documents)

    elapsed = time.perf_counter() - start

    return documents_by_question, elapsed


# 3. 검색 문서를 프롬프트용 텍스트로 변환
def format_contexts(documents):
    return "\n\n".join(
        f"Document {index}\n"
        f"Source: {document['filename']}\n"
        f"Content:\n{document['text']}"
        for index, document in enumerate(documents, start=1)
    )


# 4. RAG 답변 생성
def generate_answer(model, tokenizer, generation_config, question, documents, prompt_config):
    contexts = format_contexts(documents)
    user_prompt = prompt_config["user_template"].format(question=question, contexts=contexts)

    messages = [
        {
            "role": "system",
            "content": prompt_config["system"],
        },
        {
            "role": "user",
            "content": user_prompt,
        },
    ]

    inputs = tokenizer.apply_chat_template(messages, tokenize=True, add_generation_prompt=True, return_dict=True, return_tensors="pt").to(model.device)
    input_tokens = inputs["input_ids"].shape[1]

    torch.cuda.synchronize()
    start = time.perf_counter()

    with torch.inference_mode():
        outputs = model.generate(**inputs, generation_config=generation_config)

    torch.cuda.synchronize()
    seconds = time.perf_counter() - start
    answer = tokenizer.decode( outputs[0, input_tokens:], skip_special_tokens=True).strip()

    return answer, seconds, input_tokens


# 5. Validation 데이터 전체 답변 생성
def create_predictions(records, config):
    method = config["retrieval"]["method"]
    top_k = config["retrieval"]["top_k"]

    questions = [record["question"] for record in records]
    documents_by_question, retrieval_seconds = retrieve_all(questions, method, top_k)

    if len(documents_by_question) != len(records):
        raise RuntimeError("검색 결과 개수가 질문 개수와 다릅니다.")

    model, tokenizer, generation_config = load_model(config)

    torch.cuda.reset_peak_memory_stats()

    rows = []
    generation_seconds = 0.0
    total_input_tokens = 0

    for index, (record, documents) in enumerate(zip(records, documents_by_question), start=1):
        answer, seconds, input_tokens = generate_answer(
            model,
            tokenizer,
            generation_config,
            record["question"],
            documents,
            config["prompt"],
        )

        generation_seconds += seconds
        total_input_tokens += input_tokens

        rows.append({
            "id": record["id"],
            "question": record["question"],
            "reference_answer": record["answer"],
            "is_impossible": record["is_impossible"],
            "prediction": answer,
            "retrieved_documents": documents,
            "input_tokens": input_tokens,
        })

        print(f"Generated: {index}/{len(records)}", flush=True)

    stats = {
        "retrieval_seconds": round(retrieval_seconds, 3),
        "generation_seconds": round(generation_seconds, 3),
        "avg_input_tokens": round(total_input_tokens / len(records), 1),
        "peak_gpu_memory_gb": round(torch.cuda.max_memory_allocated() / (1024 ** 3), 3),
    }

    return rows, stats


# 6. RAG 평가 실행
def run(args):
    config = load_config(args.config)
    dataset_path = PROJECT_DIR / config["dataset"]["path"]

    with open(dataset_path, "r", encoding="utf-8") as f:
        records = json.load(f)

    expected_count = config["dataset"]["expected_count"]

    if len(records) != expected_count:
        raise ValueError(
            f"Validation 데이터 개수 불일치: "
            f"expected={expected_count}, actual={len(records)}"
        )

    output_dir = PROJECT_DIR / config["output"]["directory"]
    output_dir.mkdir(parents=True, exist_ok=True)

    rows, performance = create_predictions(records, config)

    metrics = score_predictions(records, rows, "clean", config["inference"]["batch_size"])
    metrics.update({
        "retriever": config["retrieval"]["method"],
        "top_k": config["retrieval"]["top_k"],
        **performance,
    })

    predictions_path = output_dir / "predictions.jsonl"
    metrics_path = output_dir / "metrics.json"

    save_jsonl(predictions_path, rows)

    return report(metrics, metrics_path)


# 7. CLI 실행
def main(argv=None):
    parser = argparse.ArgumentParser(description="RAG 성능 평가")
    parser.add_argument("--config", type=Path, default=PROJECT_DIR / "configs/rag/v1.yaml")

    return run(parser.parse_args(argv))


if __name__ == "__main__":
    main()