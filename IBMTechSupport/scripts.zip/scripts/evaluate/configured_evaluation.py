"""YAML-driven first-pass evaluations, leaving legacy evaluators unchanged."""
import argparse
import copy
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
from string import Formatter
from types import FunctionType
from uuid import uuid4

from . import common


def project_path(value):
    path = Path(value)
    return path.resolve() if path.is_absolute() else (common.PROJECT_DIR / path).resolve()


def load_config(experiment, config_path=None):
    import yaml

    path = Path(config_path) if config_path else common.PROJECT_DIR / "configs" / experiment / "v1.yaml"
    if not path.is_file():
        path = project_path(path)

    raw = path.read_bytes()
    config = yaml.safe_load(raw)

    if not isinstance(config, dict) or config.get("experiment") != experiment:
        raise ValueError(f"Expected experiment: {experiment}")
    
    if config.get("version") != "v1":
        raise ValueError("First-pass evaluation requires version v1")
    
    model = config["model"]
    if not isinstance(model["name"], str) or not model["name"].strip():
        raise ValueError("model.name must be nonempty")
    
    if model["dtype"] not in ("float16", "bfloat16", "float32"):
        raise ValueError("Unsupported model.dtype")
    
    model_path = project_path(model["path"])
    if not (model_path / "config.json").is_file():
        raise FileNotFoundError(f"Local model config not found: {model_path}")
    
    dataset_path = project_path(config["dataset"]["path"])
    if dataset_path != (common.DATA_DIR / "val.json").resolve():
        raise ValueError("Both experiments must use data/processed/val.json")
    
    count = config["dataset"]["expected_count"]
    if type(count) is not int or count < 1:
        raise ValueError("dataset.expected_count must be a positive integer")
    
    inference = config["inference"]
    allowed = {"batch_size", "max_new_tokens", "do_sample", "num_beams", "temperature", "top_p", "top_k"}
    if set(inference) - allowed:
        raise ValueError(f"Unknown inference options: {set(inference) - allowed}")
    
    for key in ("batch_size", "max_new_tokens", "num_beams"):
        if type(inference[key]) is not int or inference[key] < 1:
            raise ValueError(f"inference.{key} must be positive")
        
    if type(inference["do_sample"]) is not bool:
        raise ValueError("inference.do_sample must be boolean")
    
    if inference.get("temperature") is not None and inference["temperature"] <= 0:
        raise ValueError("temperature must be positive")
    
    if inference.get("top_p") is not None and not 0 < inference["top_p"] <= 1:
        raise ValueError("top_p must be in (0, 1]")
    
    if inference.get("top_k") is not None and (type(inference["top_k"]) is not int or inference["top_k"] < 1):
        raise ValueError("top_k must be a positive integer or null")
    
    if experiment == "rag":
        retrieval = config["retrieval"]
        if retrieval["method"] not in ("hybrid", "reranker") or type(retrieval["top_k"]) is not int or not 1 <= retrieval["top_k"] <= 50:
            raise ValueError("Invalid retrieval method/top_k")
        
        if inference["batch_size"] != 1:
            raise ValueError("Legacy RAG generation requires batch_size=1")
        
        from .common import DATA_DIR
        if not (DATA_DIR / "hybrid_bm25_index" / "params.index.json").is_file():
            raise FileNotFoundError("Build the existing Hybrid BM25 index before evaluation")
        
    prompt = config["prompt"]
    if not isinstance(prompt["system"], str) or not prompt["system"].strip():
        raise ValueError("prompt.system must be nonempty")
    
    fields = {field for _, field, _, _ in Formatter().parse(prompt["user_template"]) if field is not None}
    required = {"question", "contexts"} if experiment == "rag" else {"question"}
    if fields != required:
        raise ValueError(f"user_template must contain exactly {required}")
    
    output = project_path(config["output"]["directory"])
    expected_output = (common.RESULT_DIR / experiment / "v1").resolve()

    if output != expected_output:
        raise ValueError(f"output.directory must be {expected_output}")
    
    return config, raw, path.resolve()


def prepare(experiment, config_path=None):
    config, raw, source = load_config(experiment, config_path)
    records = common.load_records(str(project_path(config["dataset"]["path"])))
    expected = config["dataset"]["expected_count"]
    summary = {
        "experiment": experiment, "config": str(source),
        "model": config["model"], "inference": config["inference"],
        "dataset": str(project_path(config["dataset"]["path"])),
        "actual_count": len(records), "expected_count": expected,
        "dataset_count_matches": len(records) == expected,
        "answerable": sum(not r["is_impossible"] for r in records),
        "impossible": sum(r["is_impossible"] for r in records),
        "dataset_sha256": hashlib.sha256(project_path(config["dataset"]["path"]).read_bytes()).hexdigest(),
        "output_directory": str(project_path(config["output"]["directory"])),
        "gpu_inference_executed": False,
    }
    return config, raw, records, summary


def load_model(config):
    import torch
    from transformers import AutoModelForCausalLM, AutoTokenizer

    if not torch.cuda.is_available():
        raise RuntimeError("CUDA GPU is required")

    path = project_path(config["model"]["path"])
    tokenizer = AutoTokenizer.from_pretrained(path, local_files_only=True)
    tokenizer.padding_side = "left"

    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    model = AutoModelForCausalLM.from_pretrained(
        path, dtype=getattr(torch, config["model"]["dtype"]),
        device_map="auto", local_files_only=True,
    )
    model.eval()

    if {p.device.type for p in model.parameters()} != {"cuda"}:
        raise RuntimeError("The entire model must be on CUDA")
    
    generation = copy.deepcopy(model.generation_config)
    for key, value in config["inference"].items():
        if key != "batch_size":
            setattr(generation, key, value)

    generation.pad_token_id = tokenizer.pad_token_id
    return model, tokenizer, generation


def bind_legacy(function, **bindings):
    namespace = {**function.__globals__, **bindings}
    bound = FunctionType(function.__code__, namespace, function.__name__,
                         function.__defaults__, function.__closure__)
    bound.__kwdefaults__ = function.__kwdefaults__

    return bound


def build_rag_prompt(config, question, documents):
    if not documents:
        raise ValueError("No retrieved documents")
    
    contexts = "\n\n".join(
        f"[Document {rank}]\nFilename: {doc['filename']}\nContent:\n{doc['text']}"
        for rank, doc in enumerate(documents, 1)
    )

    return [{"role": "system", "content": config["prompt"]["system"]},
            {"role": "user", "content": config["prompt"]["user_template"].format(question=question, contexts=contexts)}]


def create_predictions(config, records):
    experiment = config["experiment"]
    if experiment == "base":
        import evaluate_base_model as legacy

        generate = bind_legacy(legacy.generate_batch, SYSTEM_PROMPT=config["prompt"]["system"])

        def generate_batch(model, tokenizer, generation, questions):
            questions = [config["prompt"]["user_template"].format(question=q) for q in questions]
            return generate(model, tokenizer, generation, questions)

        predict = bind_legacy(legacy.make_prediction_rows, generate_batch=generate_batch)
        model, tokenizer, generation = load_model(config)
        rows, seconds, memory = predict(model, tokenizer, generation, records, config["inference"]["batch_size"])
        return rows, {"generation_seconds": seconds,
                      "questions_per_second": round(len(records) / seconds, 3) if seconds > 0 else None,
                      "peak_gpu_memory_gb": memory}
    import rag_pipeline

    def build_prompt(question, documents):
        return build_rag_prompt(config, question, documents)

    generate = bind_legacy(rag_pipeline.generate_rag_answer, build_rag_prompt=build_prompt)
    return create_rag_predictions(config, records, generate)


def create_rag_predictions(config, records, generate):
    import torch
    from .evaluate_rag import retrieve_all

    documents, retrieval_seconds = retrieve_all([r["question"] for r in records], config["retrieval"]["method"], config["retrieval"]["top_k"])
    
    if len(documents) != len(records):
        raise ValueError("Retrieval count differs from dataset")
    
    model, tokenizer, generation = load_model(config)
    torch.cuda.reset_peak_memory_stats()
    rows, seconds, tokens = [], 0.0, 0

    for record, docs in zip(records, documents):
        answer, elapsed, count = generate(model, tokenizer, generation, record["question"], docs)
        seconds += elapsed
        tokens += count
        rows.append({"id": record["id"], "question": record["question"],
                     "reference_answer": record["answer"], "is_impossible": record["is_impossible"],
                     "prediction": answer, "retrieved_documents": docs, "input_tokens": count})
        
    return rows, {"retrieval_seconds": round(retrieval_seconds, 3), "generation_seconds": round(seconds, 3),
                  "avg_input_tokens": round(tokens / len(records), 1),
                  "peak_gpu_memory_gb": round(torch.cuda.max_memory_allocated() / (1024 ** 3), 3)}


def score(config, records, predictions):
    metrics = common.score_predictions(records, predictions, "original", config["inference"]["batch_size"])
    # Change metadata only; all metric calculations remain in common.py.
    metrics.update(model=config["model"]["name"], max_new_tokens=config["inference"]["max_new_tokens"])

    if config["experiment"] == "rag":
        metrics.update(retriever=config["retrieval"]["method"], top_k=config["retrieval"]["top_k"])

    return metrics


def run(experiment, config_path=None, dry_run=False, predictions=None):
    config, raw, records, summary = prepare(experiment, config_path)
    if dry_run:
        print(json.dumps(summary, ensure_ascii=False, indent=2))
        return summary
    
    if not summary["dataset_count_matches"]:
        raise ValueError(f"Dataset count mismatch: expected {summary['expected_count']}, found {len(records)}. No inference executed.")
    
    if predictions:
        rows = common.load_jsonl(predictions)
        common.validate_prediction_rows(records, rows)

    root = project_path(config["output"]["directory"])
    root.mkdir(parents=True, exist_ok=True)
    run_dir = root / (datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ") + "_" + uuid4().hex[:8])
    run_dir.mkdir(exist_ok=False)

    # Preserve exact input YAML before inference, including comments/formatting.
    with (run_dir / "config.yaml").open("xb") as f:
        f.write(raw)

    if predictions:
        performance = {"prediction_source": str(Path(predictions).resolve()), "gpu_inference_executed": False}
    else:
        rows, performance = create_predictions(config, records)
        performance["gpu_inference_executed"] = True

    metrics = score(config, records, rows)
    metrics.update(performance)
    metrics.update(dataset_sha256=summary["dataset_sha256"], config_sha256=hashlib.sha256(raw).hexdigest(),
                   config_source=summary["config"], output_directory=str(run_dir))
    
    common.save_jsonl(run_dir / "predictions.jsonl", rows)
    common.save_json(run_dir / "metrics.json", metrics)
    print(json.dumps(metrics, ensure_ascii=False, indent=2))

    return metrics


def main(experiment, argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path)
    parser.add_argument("--dry-run", action="store_true", help="Validate configuration and count; no models loaded or files saved")
    parser.add_argument("--predictions", type=Path, help="Re-score existing matching predictions without inference")
    args = parser.parse_args(argv)
    
    return run(experiment, args.config, args.dry_run, args.predictions)
