"""Configuration/wiring tests; never perform model or GPU inference."""
import ast
import contextlib
import copy
import io
import json
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import Mock, patch

from . import common
from . import configured_evaluation as configured


class ConfiguredEvaluationTests(unittest.TestCase):
    def test_same_original_dataset_and_dry_run_without_inference(self):
        reports = []
        with patch.object(configured, "load_model", side_effect=AssertionError("No model load")), contextlib.redirect_stdout(io.StringIO()):
            for experiment in ("base", "rag"):
                reports.append(configured.run(experiment, dry_run=True))
        self.assertEqual(reports[0]["dataset_sha256"], reports[1]["dataset_sha256"])
        self.assertEqual(reports[0]["dataset"], str((common.DATA_DIR / "val.json").resolve()))
        self.assertEqual(reports[0]["expected_count"], 135)
        self.assertEqual(reports[0]["actual_count"], len(common.load_records("original")))
        self.assertFalse(reports[0]["gpu_inference_executed"])

    def test_count_mismatch_stops_before_model_load_and_output(self):
        config, raw, records, summary = configured.prepare("base")
        summary["dataset_count_matches"] = False
        with patch.object(configured, "prepare", return_value=(config, raw, records, summary)), patch.object(configured, "create_predictions") as predict:
            with self.assertRaisesRegex(ValueError, "Dataset count mismatch"):
                configured.run("base")
            predict.assert_not_called()

    def test_default_prompts_match_legacy_exactly(self):
        scripts = common.PROJECT_DIR / "scripts"
        for experiment, filename, constant in (("base", "evaluate_base_model.py", "SYSTEM_PROMPT"), ("rag", "rag_pipeline.py", "RAG_SYSTEM_PROMPT")):
            config, _, _ = configured.load_config(experiment)
            tree = ast.parse((scripts / filename).read_text(encoding="utf-8-sig"))
            namespace = {}
            for node in tree.body:
                if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == constant for t in node.targets):
                    namespace[constant] = ast.literal_eval(node.value)
            self.assertEqual(config["prompt"]["system"], namespace[constant])
            if experiment == "rag":
                function = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "build_rag_prompt")
                exec(compile(ast.Module(body=[function], type_ignores=[]), filename, "exec"), namespace)
                docs = [{"filename": "a.txt", "text": "a\nb"}, {"filename": "b.txt", "text": "c"}]
                self.assertEqual(configured.build_rag_prompt(config, "question", docs), namespace["build_rag_prompt"]("question", docs))

    def test_private_binding_does_not_change_legacy_globals(self):
        def function():
            return CONFIGURED_TEST_PROMPT
        bound = configured.bind_legacy(function, CONFIGURED_TEST_PROMPT="from yaml")
        self.assertEqual(bound(), "from yaml")
        self.assertNotIn("CONFIGURED_TEST_PROMPT", function.__globals__)

    def test_model_loader_uses_yaml_values_without_real_model(self):
        config, _, _ = configured.load_config("base")
        config["model"]["dtype"] = "bfloat16"
        config["inference"]["max_new_tokens"] = 17
        tokenizer = Mock(pad_token=None, eos_token="end", pad_token_id=99)
        model = Mock(generation_config=SimpleNamespace())
        model.parameters.return_value = iter([SimpleNamespace(device=SimpleNamespace(type="cuda"))])
        transformers = SimpleNamespace(AutoTokenizer=Mock(), AutoModelForCausalLM=Mock())
        transformers.AutoTokenizer.from_pretrained.return_value = tokenizer
        transformers.AutoModelForCausalLM.from_pretrained.return_value = model
        torch = SimpleNamespace(cuda=SimpleNamespace(is_available=lambda: True), bfloat16="mock-bfloat16")
        with patch.dict(sys.modules, {"torch": torch, "transformers": transformers}):
            _, loaded_tokenizer, generation = configured.load_model(config)
        self.assertEqual(transformers.AutoModelForCausalLM.from_pretrained.call_args.kwargs["dtype"], "mock-bfloat16")
        self.assertEqual(transformers.AutoModelForCausalLM.from_pretrained.call_args.args[0], configured.project_path(config["model"]["path"]))
        self.assertEqual(generation.max_new_tokens, 17)
        self.assertFalse(generation.do_sample)
        self.assertEqual(loaded_tokenizer.padding_side, "left")
        model.generate.assert_not_called()

    def test_metric_calculations_are_unchanged(self):
        for prefix in ("base_val_clean_b4", "rag_val_clean_hybrid_k5", "rag_val_clean_reranker_k5", "base_val_original_b1"):
            source = common.RESULT_DIR / (prefix + "_predictions.jsonl")
            if not source.exists():
                continue
            rows = common.load_jsonl(source)
            dataset = "original" if "original" in prefix else "clean"
            records = common.load_records(dataset)
            expected = common.score_predictions(records, copy.deepcopy(rows), dataset, 1)
            config, _, _ = configured.load_config("rag" if prefix.startswith("rag") else "base")
            actual = configured.score(config, records, copy.deepcopy(rows))
            for key in ("exact_match_percent", "token_f1_percent", "abstention_rate_percent", "false_refusal_rate_percent", "answerable", "impossible", "total"):
                self.assertEqual(actual[key], expected[key], (prefix, key))

    def test_run_preserves_all_three_artifacts_and_never_overwrites(self):
        config, raw, _ = configured.load_config("base")
        record = {"id": "a", "question": "q", "answer": "a", "is_impossible": False}
        row = {"id": "a", "question": "q", "reference_answer": "a", "is_impossible": False, "prediction": "a"}
        with tempfile.TemporaryDirectory() as temp:
            config["output"]["directory"] = temp
            summary = {"dataset_count_matches": True, "dataset_sha256": "test", "config": "test.yaml"}
            prepared = (config, raw, [record], summary)
            source = Path(temp) / "input.jsonl"
            source.write_text(json.dumps(row) + "\n", encoding="utf-8")
            with patch.object(configured, "prepare", return_value=prepared), patch.object(configured, "create_predictions", side_effect=AssertionError("No inference")), contextlib.redirect_stdout(io.StringIO()):
                first = configured.run("base", predictions=source)
                second = configured.run("base", predictions=source)
            self.assertNotEqual(first["output_directory"], second["output_directory"])
            for result in (first, second):
                directory = Path(result["output_directory"])
                self.assertEqual((directory / "config.yaml").read_bytes(), raw)
                self.assertEqual(common.load_jsonl(directory / "predictions.jsonl")[0]["prediction"], "a")
                self.assertEqual(json.loads((directory / "metrics.json").read_text())["exact_match_percent"], 100)
            self.assertEqual(source.read_text(encoding="utf-8"), json.dumps(row) + "\n")


if __name__ == "__main__":
    unittest.main()
