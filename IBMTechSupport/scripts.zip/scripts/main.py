import argparse
import sys

from pathlib import Path
from evaluate import evaluate_base

def main_llm():
    parser = argparse.ArgumentParser()

    parser.add_argument("--mode", choices=["rag", "evaluate"], default="rag")
    parser.add_argument("--question", type=str)
    parser.add_argument("--retriever", choices=["hybrid", "reranker"], default="reranker")
    parser.add_argument("--top-k", type=int, default=5)

    args = parser.parse_args()

    if args.mode == "rag":
        from rag_pipeline import run_rag

        if not args.question:
            parser.error("--question이 필요합니다")

        if not 1 <= args.top_k <= 50:
            parser.error("--top-k는 1~50 사이어야 합니다")

        run_rag(question=args.question, method=args.retriever, top_k=args.top_k)

    elif args.mode =="evaluate":
        from ragas_evaluate import run_evaluation

        question_ids = [
            "TRAIN_Q169",
            # "TRAIN_Q137",
            # "TRAIN_Q270",
            # "TRAIN_Q113",
            # "TRAIN_Q169",
            # "DEV_Q061",
        ]
        for question_id in question_ids:
            run_evaluation(question_id)

def create_parser():
    parser = argparse.ArgumentParser(description="IBMTechSupport 평가 실행")
    tasks = parser.add_subparsers(dest="task", required=True)

    # Base LLM 평가 (추후 RAG 등의 평가 명령 추가)
    base = tasks.add_parser("base", help="Base LLM 성능 평가")
    base.add_argument("--dataset", choices=("clean", "original"), default="clean")
    base.add_argument("--batch-size", type=int, default=4)
    base.add_argument("--limit", type=int, default=0)
    base.add_argument("--reuse", action="store_true")
    base.add_argument(
        "--predictions", type=Path, default=None,
        help="--reuse 시 기존 JSONL 파일 경로 (미지정 시 현재 Batch 출력 사용)",
    )
    base.add_argument("--output", type=Path)
    base.add_argument("--save-predictions", type=Path)
    
    return parser

def main():
    if len(sys.argv) > 1 and sys.argv[1] == "base":
        args = create_parser().parse_args()
        evaluate_base.run(args)
    else:
        main_llm()

if __name__ == "__main__":
    main()
